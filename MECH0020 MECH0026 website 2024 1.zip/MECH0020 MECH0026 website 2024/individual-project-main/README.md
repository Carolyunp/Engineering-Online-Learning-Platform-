# This is my MECH0020 Individual Project 

for theory section include reading materials etc.

possible idea to include walk through questions. 


for the contact page make it so that students can write improvements on the website.
